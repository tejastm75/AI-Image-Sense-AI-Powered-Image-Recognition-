import streamlit as st
import tensorflow as tf
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input, decode_predictions
import numpy as np
from PIL import Image

# Load model
st.write("⏳ Loading model...")
try:
    model = MobileNetV2(weights="imagenet")
    st.write("✅ Model loaded successfully!")
except Exception as e:
    st.write("❌ Error loading model:", e)

# UI
st.title("🖼️ Image Classification App")
uploaded_file = st.file_uploader("Upload Image", type=["jpg", "png", "jpeg"])

if uploaded_file:
    try:
        st.write("📂 Processing image...")
        
        # Load & display image
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_column_width=True)

        # Preprocess
        image = image.resize((224, 224))
        image_array = np.array(image)
        image_array = np.expand_dims(image_array, axis=0)
        image_array = preprocess_input(image_array)

        # Predict
        st.write("🤖 Making predictions...")
        predictions = model.predict(image_array)
        decoded_predictions = decode_predictions(predictions, top=3)[0]

        # Show results
        st.write("### Predictions:")
        for i, (imagenet_id, label, score) in enumerate(decoded_predictions):
            st.write(f"**{i+1}. {label}** - {score*100:.2f}%")

        st.write("✅ Done!")

    except Exception as e:
        st.write("❌ Error processing image:", e)
