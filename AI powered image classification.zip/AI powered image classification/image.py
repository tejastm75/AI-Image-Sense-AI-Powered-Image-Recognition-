import tensorflow as tf
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input, decode_predictions
import numpy as np
from PIL import Image
import requests
import io

def classify_image(image_path):
    # Load pre-trained MobileNetV2 model
    model = MobileNetV2(weights='imagenet')
    
    # Load and preprocess the image
    if image_path.startswith("http"):
        response = requests.get(image_path)
        image = Image.open(io.BytesIO(response.content))
    else:
        image = Image.open(image_path)
    
    image = image.resize((224, 224))  # Resize to match model input size
    image_array = np.array(image)
    image_array = np.expand_dims(image_array, axis=0)
    image_array = preprocess_input(image_array)
    
    # Make predictions
    predictions = model.predict(image_array)
    decoded_predictions = decode_predictions(predictions, top=3)[0]
    
    # Print top 3 predictions
    print("Predictions:")
    for i, (imagenet_id, label, score) in enumerate(decoded_predictions):
        print(f"{i+1}: {label} ({score*100:.2f}%)")

# Example usage
image_path = "https://tse2.mm.bing.net/th?id=OIP.Hzk9_--egkrLKJ7ksIU72gHaEI&pid=Api&P=0&h=180"
classify_image(image_path)
