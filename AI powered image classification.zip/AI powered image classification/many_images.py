import tensorflow as tf
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input, decode_predictions
import numpy as np
from PIL import Image
import requests
import io
import os
import csv

def classify_images(image_paths, output_file="classification_results.csv"):
    # Load pre-trained MobileNetV2 model
    model = MobileNetV2(weights='imagenet')
    results = []
    
    for image_path in image_paths:
        print(f"Processing: {image_path}")
        
        # Load and preprocess the image
        if image_path.startswith("http"):
            response = requests.get(image_path)
            image = Image.open(io.BytesIO(response.content))
        else:
            image = Image.open(image_path)
        
        image = image.resize((224, 224))  # Resize to match model input size
        image_array = np.array(image)
        image_array = np.expand_dims(image_array, axis=0)
        image_array = preprocess_input(image_array)
        
        # Make predictions
        predictions = model.predict(image_array)
        decoded_predictions = decode_predictions(predictions, top=3)[0]
        
        # Store results
        image_results = [image_path]
        print("Predictions:")
        for i, (imagenet_id, label, score) in enumerate(decoded_predictions):
            print(f"{i+1}: {label} ({score*100:.2f}%)")
            image_results.append(f"{label} ({score*100:.2f}%)")
        print("-" * 40)
        
        results.append(image_results)
    
    # Save results to CSV
    with open(output_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Image Path", "Prediction 1", "Prediction 2", "Prediction 3"])
        writer.writerows(results)
    
    print(f"Results saved to {output_file}")

# Example usage
image_paths =  ["https://tse1.mm.bing.net/th?id=OIP.lpN0wHyDSx3b1uWpUWmCfQHaE8&pid=Api&P=0&h=180",
                "https://s.yimg.com/uu/api/res/1.2/2gbpHiy7TBwRsKdV2sGcoA--~B/aD0yNTQwO3c9MzY5NjtzbT0xO2FwcGlkPXl0YWNoeW9u/http://media.zenfs.com/en-US/homerun/time_72/28403c2254020ecde290f27b176bc980",
                  "https://wallpaperaccess.com/full/3834675.jpg"]   # Provide local image paths or URLs
classify_images(image_paths)
