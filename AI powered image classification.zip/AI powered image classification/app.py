import streamlit as st
import tensorflow as tf
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input, decode_predictions
import numpy as np
from PIL import Image, ImageFilter
import time
import pandas as pd
import plotly.express as px

# Load the MobileNetV2 model
model = MobileNetV2(weights='imagenet')

# Streamlit UI
st.title("🖼️ AI-Powered Image Analyzer")

# Create tabs
tab1, tab2, tab3 = st.tabs(["📸 Image Classification", "🕵️ Object Detection", "🎨 Image Enhancements"])

# ----- IMAGE CLASSIFICATION -----
with tab1:
    st.header("Image Classification")
    st.write("Upload an image to classify objects.")

    uploaded_files = st.file_uploader("Upload Images", type=["jpg", "png", "jpeg"], accept_multiple_files=True)

    if uploaded_files:
        for uploaded_file in uploaded_files:
            # Show image
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded Image", use_column_width=True)

            # Progress bar
            progress_bar = st.progress(0)
            for percent_complete in range(100):
                time.sleep(0.01)  # Simulating delay
                progress_bar.progress(percent_complete + 1)
            st.success("Processing Complete ✅")

            # Preprocess image
            image = image.resize((224, 224))
            image_array = np.array(image)
            image_array = np.expand_dims(image_array, axis=0)
            image_array = preprocess_input(image_array)

            # Predict
            predictions = model.predict(image_array)
            decoded_predictions = decode_predictions(predictions, top=3)[0]

            # Show predictions as a table
            st.write("### Predictions:")
            labels = [label for (_, label, _) in decoded_predictions]
            scores = [score * 100 for (_, _, score) in decoded_predictions]
            df = pd.DataFrame({"Label": labels, "Confidence (%)": scores})
            st.dataframe(df)

            # Display bar chart
            fig = px.bar(df, x="Label", y="Confidence (%)", color="Label", title="Prediction Confidence")
            st.plotly_chart(fig)

# ----- OBJECT DETECTION (FUTURE IMPLEMENTATION) -----
with tab2:
    st.header("🚧 Object Detection (Coming Soon) 🚧")
    st.write("This feature will allow users to detect objects in images.")

# ----- IMAGE ENHANCEMENTS -----
with tab3:
    st.header("🎨 Image Enhancements")
    uploaded_image = st.file_uploader("Upload an image to enhance", type=["jpg", "png", "jpeg"])

    if uploaded_image:
        # Show side-by-side images
        col1, col2 = st.columns(2)
        with col1:
            image = Image.open(uploaded_image)
            st.image(image, caption="Original Image", use_column_width=True)

        with col2:
            enhanced_image = image.filter(ImageFilter.SHARPEN)
            st.image(enhanced_image, caption="Enhanced Image", use_column_width=True)

        st.success("Enhancement Applied! ✨")
